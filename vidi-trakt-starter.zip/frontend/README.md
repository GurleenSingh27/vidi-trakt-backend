# Vidi Trakt Frontend (GitHub Pages)

Test pages to drive your backend:

- `test-vercel.html` → full device flow tester (edit the Backend URL input)
- `post-device.html`  → POST to `/trakt/device` without CORS
- `post-poll.html`    → POST to `/trakt/poll` without CORS
- `redirect.html`     → optional placeholder for Trakt Redirect URI

## GitHub Pages
Repo → Settings → Pages → Deploy from branch → `main` / `/`

## Update backend domain
Search & replace `<YOUR_BACKEND_DOMAIN>` with your actual Vercel domain
(e.g., `my-trakt-backend.vercel.app`).
